export class ClienteAdjuntos {
    id: number;
    clienteId: number;
    clienteGestionId: number;
    archivo: any;
    // name: string;
    // fullPath: string;
    // private Panel.TiposAdjuntos clTipoAdjuntoId;
    // private DateTime clFecVencimiento;

    // constructor(
    //     id: number = 0,
    //     clienteId: number = 0,
    //     ClienteGestionId: number = 0,
    //     archivo: [],
    //     // name: string = "",
    //     // fullPath: string = ""
    //     ){
    //     this.id = id;
    //     this.clienteId = clienteId;
    //     this.clienteGestionId = ClienteGestionId;
    //     this.archivo = archivo;
    //     // this.name = name;
    //     // this.fullPath = fullPath;
    // }
}