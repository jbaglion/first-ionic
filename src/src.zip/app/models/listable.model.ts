// export interface listable {
//     ID: string;
//     Descripcion: string;
//   }

  export class listable {
    constructor(    public id: string,
                    public descripcion: string) {
    }
  }
  