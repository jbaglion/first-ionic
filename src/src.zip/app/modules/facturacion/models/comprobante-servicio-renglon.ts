export interface ServicioRenglon {
  codigo: number;
  concepto: string;
  cantidad: number;
  unitario: number;
  importe: number;
}
