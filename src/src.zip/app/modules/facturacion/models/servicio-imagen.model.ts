export interface ServicioImagen {
  path: string;
  nombre: string;
  fullPath: string;
 }
