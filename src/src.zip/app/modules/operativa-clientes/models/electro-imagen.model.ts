export interface ElectroImagen {
  path: string;
  nombre: string;
  fullPath: string;
 }
