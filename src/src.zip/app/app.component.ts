import { Component } from '@angular/core';
import { Platform } from '@ionic/angular';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { Router } from '@angular/router';
import { AuthenticationService } from './modules/security/authentication.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  template: '<app-header></app-header><router-outlet></router-outlet><app-footer></app-footer>',
  styles: []
})
export class AppComponent {
  title = 'ExtranetApps-angular';

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private router: Router,
    private authenticationService: AuthenticationService
  ) {
    this.initializeApp();
  }

  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
      // this.authenticationService.login('jonathan.baglione', 'ahj026').pipe(first())
      this.authenticationService.login('javier', 'jj4842908').pipe(first())
    .subscribe(
      data => {
        // this.router.navigate(['afiliaciones']);
        console.log('ok');
      },
      error => {
        console.log(error);
        // this.authenticationService.logout();
      });
    });
  }
}
